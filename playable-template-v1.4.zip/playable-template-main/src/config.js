export const config = {
  adNetworkType: "ironsource",
  googlePlayStoreLink:
    "https://play.google.com/store/apps/details?id=com.SolidDreamsStudio.WebSlingingRace",
  appleStoreLink: "https://apps.apple.com/us/app/brawl-stars/id1229016807",
};